/*
 * Basic service worker for offline support.
 *
 * This service worker implements a cache‑first strategy: when a resource
 * is requested it will try to serve the cached version first, falling
 * back to the network if unavailable. Cached assets are defined in the
 * PRECACHE array. If you add new static files you wish to cache for
 * offline usage, include them here.
 */

const CACHE_NAME = 'hourly-tracker-v1';
const PRECACHE = [
  '/',
  '/index.html',
  '/static/style.css',
  '/static/script.js',
  '/static/manifest.json',
  '/static/sw.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE);
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return (
        cachedResponse ||
        fetch(event.request).then((response) => {
          return response;
        })
      );
    })
  );
});
