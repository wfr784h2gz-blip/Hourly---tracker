// script.js
// Handles interactions for the Hourly Tracker app. Uses jQuery for concise
// AJAX calls.

$(function () {
  const startBtn = $('#startBtn');
  const stopBtn = $('#stopBtn');
  const startTimeText = $('#startTimeText');
  const endTimeText = $('#endTimeText');
  const totalTimeDisplay = $('#totalTimeDisplay');
  const overtimeDisplay = $('#overtimeDisplay');

  // Set callout date to today by default
  const todayStr = new Date().toISOString().split('T')[0];
  $('#calloutDate').val(todayStr);

  function loadData() {
    try {
      const raw = localStorage.getItem('hourlyTrackerData');
      if (raw) {
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Failed to parse stored data', e);
    }
    return { entries: [], callouts: [], activeEntry: null };
  }

  function saveData(data) {
    localStorage.setItem('hourlyTrackerData', JSON.stringify(data));
  }

  function calculateHours(start, end) {
    const deltaMs = end - start;
    const totalHours = deltaMs / 1000 / 3600;
    const regularHours = Math.min(totalHours, 8.0);
    const overtimeHours = Math.max(totalHours - regularHours, 0.0);
    return [totalHours, overtimeHours];
  }

  function updateSummary() {
    const data = loadData();
    const today = new Date().toISOString().split('T')[0];
    let totalHours = 0;
    let overtimeHours = 0;
    let hoursPay = 0;
    let overtimePay = 0;
    let weekdayPay = 0;
    let weekendPay = 0;
    data.entries.forEach((e) => {
      if (e.entry_date === today && e.end_time) {
        totalHours += e.total_hours;
        overtimeHours += e.overtime_hours;
        hoursPay += e.hours_pay;
        overtimePay += e.overtime_pay;
      }
    });
    data.callouts.forEach((co) => {
      if (co.callout_date === today) {
        if (co.callout_type === 'weekday') {
          weekdayPay += co.pay;
        } else {
          weekendPay += co.pay;
        }
      }
    });
    $('#regHours').text((totalHours - overtimeHours).toFixed(2) + ' h');
    $('#otHours').text(overtimeHours.toFixed(2) + ' h');
    $('#totalHours').text(totalHours.toFixed(2) + ' h');
    $('#regPay').text('$' + hoursPay.toFixed(2));
    $('#otPay').text('$' + overtimePay.toFixed(2));
    $('#totalPay').text('$' + (hoursPay + overtimePay).toFixed(2));
    $('#weekdayPay').text('$' + weekdayPay.toFixed(2));
    $('#weekendPay').text('$' + weekendPay.toFixed(2));
    $('#totalCalloutPay').text('$' + (weekdayPay + weekendPay).toFixed(2));
  }

  function populateEntries() {
    const data = loadData();
    const entries = [...data.entries];
    if (data.activeEntry) {
      entries.push(data.activeEntry);
    }
    entries.sort((a, b) => {
      // sort by date then start time descending
      const keyA = a.entry_date + 'T' + a.start_time;
      const keyB = b.entry_date + 'T' + b.start_time;
      return keyB.localeCompare(keyA);
    });
    const tbody = $('table tbody');
    tbody.find('tr').remove();
    if (entries.length === 0) {
      tbody.append('<tr id="noEntriesRow"><td colspan="8" class="text-center">No entries yet.</td></tr>');
      startBtn.prop('disabled', false);
      stopBtn.prop('disabled', true);
      startTimeText.text('--:--');
      endTimeText.text('--:--');
      totalTimeDisplay.text('0h 0m');
      overtimeDisplay.text('0h overtime');
      return;
    }
    let activeFound = false;
    entries.slice(0, 10).forEach((e) => {
      const totalPay = (e.hours_pay || 0) + (e.overtime_pay || 0) + (e.callout_pay || 0);
      tbody.append(
        `<tr>
          <td>${e.entry_date}</td>
          <td>${e.start_time}</td>
          <td>${e.end_time || '--:--'}</td>
          <td>${e.total_hours !== undefined && e.total_hours !== null ? e.total_hours.toFixed(2) : '--'}</td>
          <td>${e.overtime_hours !== undefined && e.overtime_hours !== null ? e.overtime_hours.toFixed(2) : '--'}</td>
          <td>$${e.hours_pay !== undefined && e.hours_pay !== null ? e.hours_pay.toFixed(2) : '0.00'}</td>
          <td>$${e.overtime_pay !== undefined && e.overtime_pay !== null ? e.overtime_pay.toFixed(2) : '0.00'}</td>
          <td>$${totalPay.toFixed(2)}</td>
        </tr>`
      );
      if (!e.end_time) {
        activeFound = true;
        startBtn.prop('disabled', true);
        stopBtn.prop('disabled', false);
        startTimeText.text(e.start_time);
        endTimeText.text('--:--');
        totalTimeDisplay.text('0h 0m');
        overtimeDisplay.text('0h overtime');
      }
    });
    if (!activeFound) {
      startBtn.prop('disabled', false);
      stopBtn.prop('disabled', true);
    }
  }

  // Initialize summary and entries
  updateSummary();
  populateEntries();

  // Start button handler
  startBtn.on('click', function () {
    const data = loadData();
    if (data.activeEntry) {
      alert('There is already an active session.');
      return;
    }
    const now = new Date();
    const entryDate = now.toISOString().split('T')[0];
    const startTimeStr = now.toTimeString().slice(0, 5);
    data.activeEntry = {
      id: Date.now(),
      entry_date: entryDate,
      start_time: startTimeStr,
      end_time: null,
      total_hours: null,
      overtime_hours: null,
      hours_pay: null,
      overtime_pay: null,
      callout_pay: 0.0,
    };
    saveData(data);
    startBtn.prop('disabled', true);
    stopBtn.prop('disabled', false);
    startTimeText.text(startTimeStr);
    endTimeText.text('--:--');
    totalTimeDisplay.text('0h 0m');
    overtimeDisplay.text('0h overtime');
    populateEntries();
  });

  // Stop button handler
  stopBtn.on('click', function () {
    const data = loadData();
    if (!data.activeEntry) {
      alert('No active session to stop.');
      return;
    }
    const now = new Date();
    const startParts = data.activeEntry.start_time.split(':');
    const startDateTime = new Date(data.activeEntry.entry_date + 'T' + data.activeEntry.start_time + ':00');
    const [totalHours, overtimeHours] = calculateHours(startDateTime, now);
    data.activeEntry.end_time = now.toTimeString().slice(0, 5);
    data.activeEntry.total_hours = totalHours;
    data.activeEntry.overtime_hours = overtimeHours;
    data.activeEntry.hours_pay = 32.0 * Math.min(totalHours, 8.0);
    data.activeEntry.overtime_pay = 48.0 * overtimeHours;
    data.entries.push(data.activeEntry);
    data.activeEntry = null;
    saveData(data);
    startBtn.prop('disabled', false);
    stopBtn.prop('disabled', true);
    updateSummary();
    populateEntries();
  });

  // Call‑out form submission
  $('#calloutForm').on('submit', function (e) {
    e.preventDefault();
    const data = loadData();
    const ctype = $('#calloutType').val();
    const cdate = $('#calloutDate').val();
    if (!ctype || !cdate) {
      alert('Please select a call‑out type and date.');
      return;
    }
    const pay = ctype === 'weekday' ? 25.0 : 50.0;
    data.callouts.push({
      id: Date.now(),
      callout_type: ctype,
      callout_date: cdate,
      pay: pay,
    });
    saveData(data);
    updateSummary();
    alert('Call‑out recorded.');
  });
});