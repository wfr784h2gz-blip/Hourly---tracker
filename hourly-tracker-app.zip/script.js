/*
  Hourly Tracker App logic

  This script manages the timing functionality, records entries with regular
  and overtime pay, handles call‑out tracking, and updates the UI accordingly.
  Data persists in localStorage so that refreshing the page does not reset
  previously recorded entries or call‑out information.
*/

// Constants for pay rates per hour
const REGULAR_RATE = 32; // dollars per hour (as seen in screenshot)
const OVERTIME_RATE = 48; // time and a half

// State storage
let entries = [];
let callouts = [];
let timerInterval = null;
let startTimestamp = null;

// DOM elements
const startBtn = document.getElementById('start-btn');
const stopBtn = document.getElementById('stop-btn');
const startTimeInput = document.getElementById('start-time');
const endTimeInput = document.getElementById('end-time');
const totalTimeEl = document.getElementById('total-time');
const regularHoursEl = document.getElementById('regular-hours');
const overtimeHoursEl = document.getElementById('overtime-hours');
const totalPayEl = document.getElementById('total-pay');
const entriesTableBody = document.querySelector('#entries-table tbody');
const currentDateEl = document.getElementById('current-date');
const calloutTypeSelect = document.getElementById('callout-type');
const calloutDateInput = document.getElementById('callout-date');
const calloutAmountInput = document.getElementById('callout-amount');
const addCalloutBtn = document.getElementById('add-callout-btn');
const calloutTotalEl = document.getElementById('callout-total');

// Utility: format hours as "Xh Ym"
function formatHours(hours) {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  return `${h}h ${m}m`;
}

// Utility: format currency
function formatCurrency(amount) {
  return `$${amount.toFixed(2)}`;
}

// Load saved data from localStorage
function loadData() {
  const savedEntries = localStorage.getItem('ht_entries');
  const savedCallouts = localStorage.getItem('ht_callouts');
  if (savedEntries) {
    try {
      entries = JSON.parse(savedEntries);
    } catch {
      entries = [];
    }
  }
  if (savedCallouts) {
    try {
      callouts = JSON.parse(savedCallouts);
    } catch {
      callouts = [];
    }
  }
}

// Save data to localStorage
function saveData() {
  localStorage.setItem('ht_entries', JSON.stringify(entries));
  localStorage.setItem('ht_callouts', JSON.stringify(callouts));
}

// Update the date display in header
function updateCurrentDate() {
  const now = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  currentDateEl.textContent = now.toLocaleDateString(undefined, options);
}

// Populate the entries table
function populateTable() {
  // Clear existing rows
  entriesTableBody.innerHTML = '';
  // Render newest first (reverse chronological)
  [...entries].reverse().forEach(entry => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${entry.date}</td>
      <td>${entry.start}</td>
      <td>${entry.end}</td>
      <td>${formatHours(entry.hours)}</td>
      <td>${formatHours(entry.overtime)}</td>
      <td>${formatCurrency(entry.regularPay)}</td>
      <td>${formatCurrency(entry.calloutPay)}</td>
      <td>${formatCurrency(entry.totalPay)}</td>
    `;
    entriesTableBody.appendChild(row);
  });
}

// Compute summary for today
function updateSummary() {
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  let regularHours = 0;
  let overtimeHours = 0;
  let totalPay = 0;
  let todayCalloutTotal = 0;
  entries.forEach(entry => {
    if (entry.date === today) {
      regularHours += entry.hours - entry.overtime;
      overtimeHours += entry.overtime;
      totalPay += entry.totalPay;
    }
  });
  // Sum call‑out pay separately for summary
  callouts.forEach(c => {
    if (c.date === today) {
      todayCalloutTotal += c.amount;
    }
  });
  // Update UI
  regularHoursEl.textContent = formatHours(regularHours);
  overtimeHoursEl.textContent = formatHours(overtimeHours);
  totalPayEl.textContent = formatCurrency(totalPay + todayCalloutTotal);
  calloutTotalEl.textContent = formatCurrency(todayCalloutTotal);
}

// Start timing
function startTimer() {
  startTimestamp = Date.now();
  startBtn.disabled = true;
  stopBtn.disabled = false;
  // Set start input to current time (HH:MM in 24h)
  const now = new Date();
  startTimeInput.value = now.toISOString().slice(11, 16);
  // Reset total time display
  totalTimeEl.textContent = '0h 0m';
  // Update the display every second
  timerInterval = setInterval(() => {
    const diff = (Date.now() - startTimestamp) / 3600000; // in hours
    totalTimeEl.textContent = formatHours(diff);
  }, 1000);
}

// Stop timing and record entry
function stopTimer() {
  if (!startTimestamp) return;
  clearInterval(timerInterval);
  stopBtn.disabled = true;
  startBtn.disabled = false;
  const endTimestamp = Date.now();
  const diffHours = (endTimestamp - startTimestamp) / 3600000;
  // Set end input
  const endDate = new Date(endTimestamp);
  endTimeInput.value = endDate.toISOString().slice(11, 16);
  // Compute date string
  const dateString = new Date(startTimestamp).toISOString().split('T')[0];
  // Determine overtime
  const overtime = Math.max(0, diffHours - 8);
  const regularHours = diffHours - overtime;
  // Compute pay
  const regularPay = regularHours * REGULAR_RATE;
  const overtimePay = overtime * OVERTIME_RATE;
  // Determine call‑out pay for this date
  let calloutPay = 0;
  callouts.forEach(c => {
    if (c.date === dateString) {
      calloutPay += c.amount;
    }
  });
  const totalPay = regularPay + overtimePay + calloutPay;
  // Create entry object
  const entry = {
    date: dateString,
    start: startTimeInput.value,
    end: endTimeInput.value,
    hours: diffHours,
    overtime: overtime,
    regularPay: regularPay,
    overtimePay: overtimePay,
    calloutPay: calloutPay,
    totalPay: totalPay,
  };
  entries.push(entry);
  saveData();
  populateTable();
  updateSummary();
  // Reset inputs
  startTimestamp = null;
}

// Add call‑out entry
function addCallout() {
  const dateValue = calloutDateInput.value;
  const amount = parseFloat(calloutAmountInput.value);
  if (!dateValue || isNaN(amount) || amount <= 0) {
    alert('Please enter a valid call‑out date and amount.');
    return;
  }
  callouts.push({ date: dateValue, type: calloutTypeSelect.value, amount: amount });
  saveData();
  updateSummary();
  calloutDateInput.value = '';
  calloutAmountInput.value = '25';
}

// Navigation between views (basic for demonstration)
function setupNavigation() {
  const navLinks = document.querySelectorAll('.sidebar nav a');
  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      const view = link.getAttribute('data-view');
      document.querySelectorAll('main .view').forEach(v => {
        if (v.id === view + '-view' || v.id === view) {
          v.hidden = false;
        } else {
          v.hidden = true;
        }
      });
    });
  });
}

// Initialize app
function init() {
  loadData();
  updateCurrentDate();
  populateTable();
  updateSummary();
  // Event listeners
  startBtn.addEventListener('click', startTimer);
  stopBtn.addEventListener('click', stopTimer);
  addCalloutBtn.addEventListener('click', addCallout);
  setupNavigation();
}

// Call init when DOM is ready
document.addEventListener('DOMContentLoaded', init);